#!/bin/bash -f
xv_path="/home/patrick/.local/opt/Xilinx/Vivado/2016.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim udp_ip_offload_engine_tx_axis_tb_time_synth -key {Post-Synthesis:tx:Timing:udp_ip_offload_engine_tx_axis_tb} -tclbatch udp_ip_offload_engine_tx_axis_tb.tcl -view /home/patrick/vivado/gamma-team/integration_tester/tx.wcfg -log simulate.log
