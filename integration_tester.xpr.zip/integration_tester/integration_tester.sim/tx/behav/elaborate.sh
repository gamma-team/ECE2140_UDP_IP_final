#!/bin/bash -f
xv_path="/home/patrick/.local/opt/Xilinx/Vivado/2016.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto 3b4365f4c4f74fa8a55daa65998b5559 -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L secureip -L xpm --snapshot udp_ip_offload_engine_tx_axis_tb_behav xil_defaultlib.udp_ip_offload_engine_tx_axis_tb -log elaborate.log
