UDP/IP offload engine transmitter in Vivado IP packager format, with
AXI4-Stream interfaces.

Retrieve dependencies before use:

  git submodule init
  git submodule update

src/
  Source files

component.xml
xgui/
  Vivado IP packager files
