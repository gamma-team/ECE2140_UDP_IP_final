# ip-tx-hdl
IP transmitter core for Vivado
