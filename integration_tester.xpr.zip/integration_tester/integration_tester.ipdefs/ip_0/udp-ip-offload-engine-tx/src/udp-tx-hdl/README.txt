src/
  Source files

sim/
  Testbench file
  
component.xml
xgui/
  Vivado IP packager files
