src/
  Source files
sim/
  Testbench file
