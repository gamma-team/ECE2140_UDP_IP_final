# ip-rx-hdl
IP receiver core for Vivado
