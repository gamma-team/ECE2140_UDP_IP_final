/* UDP/IP offload software integration testbench.
 *
 * Copyright (C) 2017 Patrick Gauvin. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Use of the Software is limited solely to applications:
 * (a) running on a Xilinx device, or
 * (b) that interact with a Xilinx device through a bus or interconnect.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * Except as contained in this notice, the name of the Xilinx shall not be used
 * in advertising or otherwise to promote the sale, use or other dealings in
 * this Software without prior written authorization from Xilinx.
 *
 */
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <xllfifo.h>
#include "platform.h"
#include "rx_test_data.h"
#include "tx_test_data.h"

#define ARRAY_LEN(a) (sizeof (a) / sizeof (typeof(a[0])))

#define VERBOSE
/*#define DEBUG*/
/* Uncomment accordingly to disable tests */
/*#define NO_TX*/
/*#define NO_RX*/

struct test_data {
  const char *name;
  const uint8_t *data;
  size_t data_len;
  const uint8_t *result;
  size_t result_len;
};

struct test_data rx_tests[] = {
  { "RX Integration Test 1", rx_integration_test_1,
    sizeof (rx_integration_test_1), rx_integration_test_1_res,
    sizeof (rx_integration_test_1_res) },
  { "RX Integration Test 2", rx_integration_test_2,
    sizeof (rx_integration_test_2), rx_integration_test_2_res,
    sizeof (rx_integration_test_2_res) },
  { "RX Integration Test 3", rx_integration_test_3,
    sizeof (rx_integration_test_3), rx_integration_test_3_res,
    sizeof (rx_integration_test_3_res) },
  { "RX Throughput Test 1", rx_throughput_test_1,
    sizeof (rx_throughput_test_1), rx_throughput_test_1_res,
    sizeof (rx_throughput_test_1_res) },
  { "RX Throughput Test 2", rx_throughput_test_2,
    sizeof (rx_throughput_test_2), rx_throughput_test_2_res,
    sizeof (rx_throughput_test_2_res) }
};

struct test_data tx_tests[] = {
  { "TX Integration Test 1", tx_integration_test_1,
    sizeof (tx_integration_test_1), tx_integration_test_1_res,
    sizeof (tx_integration_test_1_res) },
  /* Tests 2 and 3 Disabled because of FIFO output alignment bug */
/*  { "TX Integration Test 2", tx_integration_test_2,
    sizeof (tx_integration_test_2), tx_integration_test_2_res,
    sizeof (tx_integration_test_2_res) },
  { "TX Integration Test 3", tx_integration_test_3,
    sizeof (tx_integration_test_3), tx_integration_test_3_res,
    sizeof (tx_integration_test_3_res) },*/
  { "TX Throughput Test 1", tx_throughput_test_1,
    sizeof (tx_throughput_test_1), tx_throughput_test_1_res,
    sizeof (tx_throughput_test_1_res) },
  { "TX Throughput Test 2", tx_throughput_test_2,
    sizeof (tx_throughput_test_2), tx_throughput_test_2_res,
    sizeof (tx_throughput_test_2_res) }
};

void
hexdump (uint8_t *data, size_t len)
{
  printf ("DUMPING %p\n ", data);
  for (size_t i = 0; i < len; ++i)
    {
      if (i % 8 == 0 && i != 0)
        printf ("\n ");
      else if (i % 4 == 0 && i != 0)
        printf (" ");
      printf ("%02" PRIx8, data[i]);
    }
  printf ("\nEND DUMP\n");
}

int
send (XLlFifo *instance, const uint8_t *data, size_t len)
{
  /* Check for space */
  if (XLlFifo_TxVacancy (instance) < (len + 3) / 4)
    return -1;
  XLlFifo_Write (instance, data, len);
  XLlFifo_TxSetLen (instance, len);
#ifdef VERBOSE
  printf ("%s: Waiting for transmission to end...\n", __func__);
#endif /* VERBOSE */
  while (!(XLlFifo_IsTxDone (instance)));
  return 0;
}

/* data [out] output buffer of length len
 * len [inout] length of data in bytes, set to the number of bytes written to
 * data.
 * block [in] Set false to return immediately if no data is available.
 */
int
recv (XLlFifo *instance, uint8_t *data, size_t *len, bool block)
{
  u32 frame_len;
  uint8_t *buf;

  if (block)
    {
#ifdef VERBOSE
      printf ("%s: Waiting for input frame...\n", __func__);
#endif /* VERBOSE */
      while (0 == XLlFifo_RxOccupancy (instance));
    }
  else
    if (0 == XLlFifo_RxOccupancy (instance))
      return -1;
  frame_len = XLlFifo_RxGetLen (instance);
#ifdef VERBOSE
  printf ("%s: Frame length %lu, requested %zu bytes.\n", __func__,
          frame_len, *len);
#endif /* VERBOSE */
  if (frame_len < *len)
    *len = frame_len;

  /* Create a temporary buffer for reading all data for this packet. According
   * to the llfifo docs, the entire frame must be read.
   */
  buf = malloc (frame_len);
  if (NULL == buf)
    {
      printf ("couldn't allocate buffer\n");
      return -1;
    }
  XLlFifo_Read (instance, buf, frame_len);
#ifdef DEBUG
  if (frame_len > 0)
    hexdump (buf, frame_len);
#endif /* DEBUG */
  memcpy (data, buf, *len);
  free (buf);
#ifdef VERBOSE
  printf ("%s: Read %zu bytes.\n", __func__, *len);
#endif /* VERBOSE */
  return 0;
}

int
init (XLlFifo *instance, u32 devid)
{
  int status;
  XLlFifo_Config *config;

  /* It really is XLlFfio... */
  config = XLlFfio_LookupConfig (devid);
  if (NULL == config)
    {
      printf ("No config found\n");
      return -1;
    }
  status = XLlFifo_CfgInitialize (instance, config, config->BaseAddress);
  if (0 != status)
    {
      printf ("Failed to initialize llfifo instance: %d\n", status);
      return -2;
    }
  /* Check for the Reset value (taken drectly from the example, haven't looked
   * at why XLlFifo_Status is called twice. */
  status = XLlFifo_Status (instance);
  XLlFifo_IntClear (instance, 0xffffffff);
  status = XLlFifo_Status (instance);
  if (0 != status)
    {
      printf ("Reset value of ISR0 : 0x%x Expected : 0x0\n\r", status);
      return -3;
    }
  return 0;
}

void
llfifo_dump_status (XLlFifo *instance)
{
  printf ("TxVacancy: %ld\n", XLlFifo_TxVacancy (instance));
  printf ("iTxVacancy: %ld\n", XLlFifo_iTxVacancy (instance));
  printf ("RxOccupancy: %ld\n", XLlFifo_RxOccupancy (instance));
  printf ("iRxOccupancy: %ld\n", XLlFifo_iRxOccupancy (instance));
}

int
loopback (XLlFifo *instance, const uint8_t *data, size_t len,
          const uint8_t *result, size_t result_len)
{
  int status;
  uint8_t *buf;
  size_t buf_len, len_read;
  bool pre_check_error;

#ifdef DEBUG
  printf ("llfifo status before send():\n");
	llfifo_dump_status (instance);
#endif /* DEBUG */
  status = send (instance, data, len);
  if (status)
    {
      printf ("send failed: %d\n", status);
      return -4;
    }
#ifdef DEBUG
	llfifo_dump_status (instance);
#endif /* DEBUG */

  /* Extra 4 bytes for issues with FIFO alignment */
  buf_len = result_len + 4;
  buf = malloc (buf_len);
  if (NULL == buf)
    {
      printf ("Failed to allocate output buffer\n");
      return -1;
    }

  /* Read data and check for error conditions based on length */
  len_read = buf_len;
  status = recv (instance, buf, &len_read, true);
  if (status)
    {
      printf ("recv failed: %d\n", status);
      status = -5;
      goto err;
    }
  pre_check_error = false;
  if (len_read > result_len)
    {
      /* Allow extra data past the end of the transfer, up to a word boundary.
       * Allows for mishandled null bytes at the end of a transfer into the
       * receive FIFO.
       */
      if (len_read - result_len > 3)
        {
					printf ("Read too much data, expected %zu, received %zu\n",
                  result_len, len_read);
          pre_check_error = true;
        }
    }
  else if (len_read > result_len)
    {
      printf ("Short read, expected %zu bytes, received %zu\n", len,
              len_read);
      pre_check_error = true;
    }

  /* Check against known-good result */
  status = 0;
  for (size_t i = 0; i < len_read && i < result_len; ++i)
    if (result[i] != buf[i])
      {
        printf ("Mismatch at byte %zu: %#" PRIx8 " != %#" PRIx8 "\n", i,
                result[i], buf[i]);
        status = 1;
      }
  if (pre_check_error)
    status = -6;
  if (0 != status)
    hexdump (buf, len_read);
err:
  free (buf);
  return status;
}

void
do_tests (XLlFifo *instance, struct test_data *tests, size_t n)
{
  int status;

  uint8_t *buf = malloc (50);
  size_t len = 50;
  for (size_t i = 0; i < n; ++i)
    {
      printf ("\nSTART: %s\n", tests[i].name);
      status = loopback (instance, tests[i].data, tests[i].data_len,
                         tests[i].result, tests[i].result_len);
      if (0 != status)
        printf ("FAILED: %d\n", status);
      else
        printf ("PASS\n");

      while (0 == recv (instance, buf, &len, false))
        len = 50;

    }
}

int
main (void)
{
  int status;
  XLlFifo instance_rx;
  XLlFifo instance_tx;

  init_platform ();
  printf ("Entering UDP/IP integration test suite\n");

#ifndef NO_RX
  status = init (&instance_rx, XPAR_AXI_FIFO_MM_S_0_DEVICE_ID);
  if (0 != status)
    {
      printf ("RX datapath LLFIFO init failed: %d\n", status);
      goto err;
    }
  do_tests (&instance_rx, rx_tests, ARRAY_LEN (rx_tests));
#endif /* NO_RX */

#ifndef NO_TX
  status = init (&instance_tx, XPAR_AXI_FIFO_MM_S_1_DEVICE_ID);
  if (0 != status)
    {
      printf ("TX datapath LLFIFO init failed: %d\n", status);
      goto err;
    }
  do_tests (&instance_tx, tx_tests, ARRAY_LEN (tx_tests));
#endif /* NO_TX */

  /* Safe exit point with cleanup */
err:
  printf ("\nExiting...\n");
  cleanup_platform ();
  return 0;
}
